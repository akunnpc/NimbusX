package com.example.presentation.ui.extensions

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import com.example.data.extension.PresetExtensions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.Extension
import com.example.domain.model.ExtensionRepo
import com.example.domain.model.ExtensionStatus
import com.example.ui.theme.AccentSuccess
import com.example.ui.theme.AccentWarning

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtensionsScreen(
    viewModel: ExtensionsViewModel,
    snackbarHostState: SnackbarHostState
) {
    val installedList by viewModel.installedExtensions.collectAsStateWithLifecycle()
    val repoList by viewModel.repositories.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showRepoDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.messageEvent.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Extension Manager",
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Daftar plugin dinamis terinstall & repository store",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(
                onClick = { showAddDialog = true },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .testTag("add_custom_extension_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Tambah Extension",
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        PrimaryTabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Terinstall (${installedList.size})") },
                icon = { Icon(Icons.Default.Extension, contentDescription = null) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Repository Catalog") },
                icon = { Icon(Icons.Default.Store, contentDescription = null) }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (isProcessing) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        }

        when (selectedTab) {
            0 -> InstalledExtensionsList(
                extensions = installedList,
                onToggle = { pkg, enabled -> viewModel.toggleExtension(pkg, enabled) },
                onUpdate = { ext -> viewModel.updateExtension(ext) },
                onDelete = { pkg -> viewModel.deleteExtension(pkg) }
            )
            1 -> ExtensionRepositoriesCatalog(
                repositories = repoList,
                onAddRepoClick = { showRepoDialog = true },
                onDeleteRepo = { id -> viewModel.deleteRepository(id) },
                onInstallPreset = { ext -> viewModel.installFromPayload(ext.scriptContent) }
            )
        }
    }

    if (showAddDialog) {
        AddExtensionDialog(
            onDismiss = { showAddDialog = false },
            onInstallPayload = { payload ->
                viewModel.installFromPayload(payload)
                showAddDialog = false
            },
            onInstallUrl = { url ->
                viewModel.installFromUrl(url)
                showAddDialog = false
            }
        )
    }

    if (showRepoDialog) {
        AddRepoDialog(
            onDismiss = { showRepoDialog = false },
            onAdd = { name, url, desc ->
                viewModel.addRepository(name, url, desc)
                showRepoDialog = false
            }
        )
    }
}

@Composable
fun InstalledExtensionsList(
    extensions: List<Extension>,
    onToggle: (String, Boolean) -> Unit,
    onUpdate: (Extension) -> Unit,
    onDelete: (String) -> Unit
) {
    if (extensions.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Belum ada extension yang terpasang.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(extensions, key = { it.pkgName }) { ext ->
                ExtensionCard(
                    extension = ext,
                    onToggle = { enabled -> onToggle(ext.pkgName, enabled) },
                    onUpdate = { onUpdate(ext) },
                    onDelete = { onDelete(ext.pkgName) }
                )
            }
        }
    }
}

@Composable
fun ExtensionCard(
    extension: Extension,
    onToggle: (Boolean) -> Unit,
    onUpdate: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("extension_card_${extension.pkgName}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Extension,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = extension.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "v${extension.versionName} • ${extension.lang.uppercase()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            BadgeChip(
                                label = extension.parserType.name,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                Switch(
                    checked = extension.status != ExtensionStatus.DISABLED,
                    onCheckedChange = onToggle,
                    modifier = Modifier.testTag("toggle_switch_${extension.pkgName}")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = extension.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Signature Valid",
                        tint = AccentSuccess,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "SHA-256 Validated",
                        style = MaterialTheme.typography.labelSmall,
                        color = AccentSuccess
                    )
                }

                Row {
                    TextButton(onClick = onUpdate) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Update")
                    }

                    IconButton(onClick = onDelete) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Hapus Extension",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ExtensionRepositoriesCatalog(
    repositories: List<ExtensionRepo>,
    onAddRepoClick: () -> Unit,
    onDeleteRepo: (String) -> Unit,
    onInstallPreset: (Extension) -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Tambah Repository Luar",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Gunakan URL indeks JSON untuk mengintegrasikan toko extension kustom.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = onAddRepoClick,
                        modifier = Modifier.testTag("add_repo_button")
                    ) {
                        Text("Tambah")
                    }
                }
            }
        }

        items(repositories, key = { it.id }) { repo ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Store, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = repo.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        IconButton(onClick = { onDeleteRepo(repo.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = repo.url, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = repo.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun AddExtensionDialog(
    onDismiss: () -> Unit,
    onInstallPayload: (String) -> Unit,
    onInstallUrl: (String) -> Unit
) {
    var selectedMethod by remember { mutableIntStateOf(0) } // 0 = Repo, 1 = URL, 2 = File Storage, 3 = Paste JSON
    var textPayload by remember { mutableStateOf("") }
    var urlPayload by remember { mutableStateOf("") }
    var selectedFileSample by remember { mutableStateOf<String?>(null) }

    val sampleUrl = "https://raw.githubusercontent.com/extension-core/official-index/main/mangadex.json"

    val sampleJsonDsl = """
{
  "pkgName": "com.extension.custom_dsl",
  "name": "Custom Source DSL",
  "versionCode": 1,
  "versionName": "1.0.0",
  "lang": "id",
  "iconUrl": "https://picsum.photos/100/100?random=dsl",
  "description": "Extension hasil paste script JSON DSL secara manual.",
  "author": "Dev Community",
  "baseUrl": "https://example.com",
  "parserType": "JSON_DSL",
  "scriptContent": "{\n  \"items\": [\n    {\n      \"id\": \"dsl_1\",\n      \"title\": \"Solo Leveling (DSL)\",\n      \"coverUrl\": \"https://picsum.photos/300/400?random=sl\",\n      \"description\": \"Manga terpopuler berbasis parser JSON DSL dinamis.\",\n      \"author\": \"Chugong\"\n    }\n  ]\n}"
}
    """.trimIndent()

    val fileStorageSamples = remember {
        listOf(
            "extension_mangadex_v1.json" to """
{
  "pkgName": "com.extension.mangadex_storage",
  "name": "MangaDex (Local Storage File)",
  "versionCode": 1,
  "versionName": "1.0.0",
  "lang": "en",
  "iconUrl": "https://picsum.photos/100/100?random=md_file",
  "description": "Diimpor dari file /sdcard/Download/extension_mangadex_v1.json",
  "author": "MangaDex Team",
  "baseUrl": "https://mangadex.org",
  "parserType": "JSON_DSL",
  "scriptContent": "{\"items\":[{\"id\":\"md_1\",\"title\":\"Frieren: Beyond Journey's End\",\"coverUrl\":\"https://picsum.photos/300/400?random=frieren\",\"description\":\"Petualangan Frieren setelah mengalahkan Raja Iblis.\",\"author\":\"Kanehito Yamada\"}]}"
}
            """.trimIndent(),
            "extension_jsoup_live.json" to """
{
  "pkgName": "com.extension.jsoup_storage",
  "name": "KomikCast Jsoup Live",
  "versionCode": 1,
  "versionName": "1.1.0",
  "lang": "id",
  "iconUrl": "https://picsum.photos/100/100?random=jsoup_file",
  "description": "Diimpor dari file /sdcard/Documents/extension_jsoup_live.json",
  "author": "Jsoup Engine",
  "baseUrl": "https://komikcast.bz",
  "parserType": "JSON_DSL",
  "scriptContent": "{\"selectors\":{\"popular\":{\"path\":\"manga-list/\",\"list\":\".list-update .animposx\",\"title\":\".title\",\"cover\":\"img@src\",\"url\":\"a@href\"}}}"
}
            """.trimIndent()
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Pasang Extension Baru",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp)
            ) {
                ScrollableTabRow(
                    selectedTabIndex = selectedMethod,
                    edgePadding = 0.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Tab(
                        selected = selectedMethod == 0,
                        onClick = { selectedMethod = 0 },
                        text = { Text("1. Repo", fontSize = 11.sp) },
                        icon = { Icon(Icons.Default.Store, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = selectedMethod == 1,
                        onClick = { selectedMethod = 1 },
                        text = { Text("2. Direct URL", fontSize = 11.sp) },
                        icon = { Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = selectedMethod == 2,
                        onClick = { selectedMethod = 2 },
                        text = { Text("3. File Storage", fontSize = 11.sp) },
                        icon = { Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = selectedMethod == 3,
                        onClick = { selectedMethod = 3 },
                        text = { Text("4. Paste JSON", fontSize = 11.sp) },
                        icon = { Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    when (selectedMethod) {
                        0 -> {
                            Text(
                                text = "Metode 1: Install dari Repository",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Pilih & pasang langsung extension terverifikasi dari katalog repository resmi atau komunitas.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "Katalog Extension Siap Pasang:",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))

                                    val presetCatalog = listOf(
                                        Triple("MangaNexus Source", "Parser JSON DSL komik & manga Indonesia", PresetExtensions.PRESET_EXTENSIONS[0]),
                                        Triple("WebNovel Reader", "Parser novel digital dengan kustomisasi font", PresetExtensions.PRESET_EXTENSIONS.getOrNull(1))
                                    )

                                    presetCatalog.forEach { (name, desc, presetExt) ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(text = name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                                Text(text = desc, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            if (presetExt != null) {
                                                Button(
                                                    onClick = { onInstallPayload(presetExt.scriptContent) },
                                                    modifier = Modifier.padding(start = 8.dp)
                                                ) {
                                                    Text("Pasang", fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        1 -> {
                            Text(
                                text = "Metode 2: Install dari Direct URL Extension",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Masukkan link langsung (direct URL) yang menunjuk ke file extension (.json / .js).",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = urlPayload,
                                onValueChange = { urlPayload = it },
                                label = { Text("URL Extension (.json / .js)") },
                                placeholder = { Text("https://raw.githubusercontent.com/.../extension.json") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("url_input_field"),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(
                                    onClick = { urlPayload = sampleUrl }
                                ) {
                                    Text("Isi Contoh URL", fontSize = 11.sp)
                                }
                            }

                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(
                                        text = "Contoh Input URL Valid:",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = sampleUrl,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }

                        2 -> {
                            Text(
                                text = "Metode 3: Import File JSON dari Storage HP",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Pilih file manifest .json extension yang sudah diunduh ke memori internal perangkat Anda.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "Pilih File dari Penyimpanan Perangkat:",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            fileStorageSamples.forEach { (fileName, jsonContent) ->
                                Card(
                                    onClick = {
                                        selectedFileSample = fileName
                                        textPayload = jsonContent
                                    },
                                    border = if (selectedFileSample == fileName) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (selectedFileSample == fileName) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.FolderOpen,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(text = fileName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                            Text(text = "Format: File Manifest JSON lokal HP", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }

                        3 -> {
                            Text(
                                text = "Metode 4: Paste Kode JSON DSL / Script JS",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tempel teks struktur JSON DSL atau parser JS secara manual ke dalam kotak teks di bawah.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "Script Manifest:", style = MaterialTheme.typography.labelMedium)
                                TextButton(onClick = { textPayload = sampleJsonDsl }) {
                                    Text("Isi Contoh JSON DSL", fontSize = 11.sp)
                                }
                            }

                            OutlinedTextField(
                                value = textPayload,
                                onValueChange = { textPayload = it },
                                label = { Text("Script / Payload JSON DSL") },
                                placeholder = { Text("{\"pkgName\": \"com.example.source\", ...}") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp)
                                    .testTag("payload_input_field"),
                                maxLines = 10
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (selectedMethod != 0) {
                Button(
                    onClick = {
                        when (selectedMethod) {
                            1 -> if (urlPayload.isNotBlank()) onInstallUrl(urlPayload)
                            2, 3 -> if (textPayload.isNotBlank()) onInstallPayload(textPayload)
                        }
                    },
                    modifier = Modifier.testTag("confirm_install_button"),
                    enabled = when (selectedMethod) {
                        1 -> urlPayload.isNotBlank()
                        2, 3 -> textPayload.isNotBlank()
                        else -> false
                    }
                ) {
                    Text("Pasang Extension")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Tutup") }
        }
    )
}

@Composable
fun AddRepoDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Repository Kustom") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama Repository") })
                OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("URL index.json") })
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Deskripsi Singkat") })
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && url.isNotBlank()) {
                        onAdd(name, url, desc.ifBlank { "Repository komunitas" })
                    }
                }
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
fun BadgeChip(label: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
            color = color
        )
    }
}
