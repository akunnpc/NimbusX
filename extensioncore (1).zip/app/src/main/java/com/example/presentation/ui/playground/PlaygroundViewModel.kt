package com.example.presentation.ui.playground

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.extension.DynamicParserEngine
import com.example.data.extension.ExtensionValidator
import com.example.domain.model.Extension
import com.example.domain.model.ExtensionStatus
import com.example.domain.model.MediaItem
import com.example.domain.model.ParserType
import com.example.domain.repository.ExtensionRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.jsoup.Jsoup

data class NetworkLogEntry(
    val timestamp: Long = System.currentTimeMillis(),
    val method: String,
    val url: String,
    val status: Int,
    val responseTimeMs: Long
)

data class ErrorLogEntry(
    val timestamp: Long = System.currentTimeMillis(),
    val source: String,
    val message: String
)

class PlaygroundViewModel(
    private val extensionRepository: ExtensionRepository,
    private val parserEngine: DynamicParserEngine = DynamicParserEngine()
) : ViewModel() {

    val sampleScript = """
    {
      "pkgName": "com.developer.sandbox_extension",
      "name": "Sandbox Custom Source",
      "versionCode": 100,
      "versionName": "1.0.0",
      "lang": "id",
      "iconUrl": "https://picsum.photos/100/100?random=sandbox",
      "description": "Custom extension yang dibuat secara live via Developer Sandbox.",
      "author": "You (Dev)",
      "baseUrl": "https://api.sandbox-demo.dev",
      "parserType": "JSON_DSL",
      "items": [
        {
          "id": "sb_item_1",
          "title": "Custom Extension Content A",
          "coverUrl": "https://picsum.photos/300/400?random=sb1",
          "description": "Item hasil evaluasi parser engine dinamis secara realtime di sandbox memori.",
          "author": "Playground Engine",
          "genres": ["Custom", "Testing", "Dynamic"]
        },
        {
          "id": "sb_item_2",
          "title": "Custom Extension Content B",
          "coverUrl": "https://picsum.photos/300/400?random=sb2",
          "description": "Item kedua yang memverifikasi isolasi sandbox dan skema JSON Validator.",
          "author": "Playground Engine",
          "genres": ["Sandbox", "Kotlin"]
        }
      ]
    }
    """.trimIndent()

    private val _scriptCode = MutableStateFlow(sampleScript)
    val scriptCode: StateFlow<String> = _scriptCode.asStateFlow()

    private val _validationResult = MutableStateFlow<ExtensionValidator.ValidationResult?>(null)
    val validationResult: StateFlow<ExtensionValidator.ValidationResult?> = _validationResult.asStateFlow()

    private val _parsedItems = MutableStateFlow<List<MediaItem>>(emptyList())
    val parsedItems: StateFlow<List<MediaItem>> = _parsedItems.asStateFlow()

    private val _isExecuting = MutableStateFlow(false)
    val isExecuting: StateFlow<Boolean> = _isExecuting.asStateFlow()

    private val _messageEvent = MutableSharedFlow<String>()
    val messageEvent: SharedFlow<String> = _messageEvent.asSharedFlow()

    // HTML Selector Test State
    private val _htmlTestUrl = MutableStateFlow("https://komikcast.bz")
    val htmlTestUrl: StateFlow<String> = _htmlTestUrl.asStateFlow()

    private val _htmlCssSelector = MutableStateFlow(".list-update .animposx .title")
    val htmlCssSelector: StateFlow<String> = _htmlCssSelector.asStateFlow()

    private val _htmlTestResults = MutableStateFlow<List<String>>(emptyList())
    val htmlTestResults: StateFlow<List<String>> = _htmlTestResults.asStateFlow()

    // Logs & Security
    private val _httpLogs = MutableStateFlow<List<NetworkLogEntry>>(
        listOf(
            NetworkLogEntry(method = "GET", url = "https://mangadex.org/api/v2/manga", status = 200, responseTimeMs = 320),
            NetworkLogEntry(method = "GET", url = "https://komikcast.bz/manga-list/", status = 200, responseTimeMs = 450)
        )
    )
    val httpLogs: StateFlow<List<NetworkLogEntry>> = _httpLogs.asStateFlow()

    private val _errorLogs = MutableStateFlow<List<ErrorLogEntry>>(emptyList())
    val errorLogs: StateFlow<List<ErrorLogEntry>> = _errorLogs.asStateFlow()

    private val _httpsEnforced = MutableStateFlow(true)
    val httpsEnforced: StateFlow<Boolean> = _httpsEnforced.asStateFlow()

    fun updateScriptCode(newCode: String) {
        _scriptCode.value = newCode
    }

    fun updateHtmlTestUrl(url: String) {
        _htmlTestUrl.value = url
    }

    fun updateHtmlCssSelector(selector: String) {
        _htmlCssSelector.value = selector
    }

    fun toggleHttpsEnforce(enabled: Boolean) {
        _httpsEnforced.value = enabled
        viewModelScope.launch {
            _messageEvent.emit(if (enabled) "Keamanan Enforce HTTPS Diaktifkan" else "Perhatian: Enforce HTTPS Dinonaktifkan")
        }
    }

    fun testJsoupCssSelector() {
        viewModelScope.launch(Dispatchers.IO) {
            _isExecuting.value = true
            val startTime = System.currentTimeMillis()
            try {
                val url = _htmlTestUrl.value
                val selector = _htmlCssSelector.value

                if (url.isBlank() || selector.isBlank()) {
                    _messageEvent.emit("URL dan CSS Selector tidak boleh kosong.")
                    return@launch
                }

                val doc = Jsoup.connect(url)
                    .userAgent("Mozilla/5.0 (Android Mobile; ExtensionCore/1.0)")
                    .timeout(8000)
                    .get()

                val elements = doc.select(selector)
                val extracted = elements.take(15).mapIndexed { idx, el -> "${idx + 1}. ${el.text()}" }

                _htmlTestResults.value = extracted
                val duration = System.currentTimeMillis() - startTime

                _httpLogs.value = listOf(NetworkLogEntry(method = "GET", url = url, status = 200, responseTimeMs = duration)) + _httpLogs.value
                _messageEvent.emit("Berhasil mengekstrak ${elements.size} elemen dari HTML ($duration ms)")
            } catch (e: Exception) {
                _errorLogs.value = listOf(ErrorLogEntry(source = "Jsoup Live Tester", message = e.localizedMessage ?: "Unknown error")) + _errorLogs.value
                _messageEvent.emit("Gagal menguji selector HTML: ${e.localizedMessage}")
            } finally {
                _isExecuting.value = false
            }
        }
    }

    fun validateAndRunTest() {
        val code = _scriptCode.value
        val validation = ExtensionValidator.validateExtensionPayload(code)
        _validationResult.value = validation

        if (validation.isValid) {
            viewModelScope.launch {
                _isExecuting.value = true
                try {
                    val json = JSONObject(code)
                    val dummyExt = Extension(
                        id = json.optString("pkgName", "com.custom.sandbox"),
                        pkgName = json.optString("pkgName", "com.custom.sandbox"),
                        name = json.optString("name", "Sandbox Test Source"),
                        versionCode = json.optInt("versionCode", 1),
                        versionName = json.optString("versionName", "1.0.0"),
                        lang = json.optString("lang", "id"),
                        iconUrl = json.optString("iconUrl", ""),
                        description = json.optString("description", ""),
                        author = json.optString("author", "Dev"),
                        baseUrl = json.optString("baseUrl", "https://example.com"),
                        parserType = ParserType.JSON_DSL,
                        status = ExtensionStatus.INSTALLED,
                        scriptContent = code
                    )

                    val results = parserEngine.parsePopular(dummyExt)
                    _parsedItems.value = results
                    _messageEvent.emit("Pengujian Sandbox Berhasil! Menemukan ${results.size} item hasil parsing.")
                } catch (e: Exception) {
                    _errorLogs.value = listOf(ErrorLogEntry(source = "Sandbox Parser Test", message = e.localizedMessage ?: "Unknown error")) + _errorLogs.value
                    _messageEvent.emit("Gagal Eksekusi: ${e.localizedMessage}")
                } finally {
                    _isExecuting.value = false
                }
            }
        } else {
            viewModelScope.launch {
                _messageEvent.emit("Validasi Gagal! Periksa tab pesan kesalahan.")
            }
        }
    }

    fun installScriptAsExtension() {
        val code = _scriptCode.value
        viewModelScope.launch {
            _isExecuting.value = true
            val result = extensionRepository.installExtensionFromPayload(code)
            _isExecuting.value = false
            result.onSuccess {
                _messageEvent.emit("Extension ${it.name} berhasil terinstall ke Extension Manager!")
            }.onFailure {
                _messageEvent.emit("Gagal menginstall: ${it.localizedMessage}")
            }
        }
    }

    class Factory(private val extensionRepository: ExtensionRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return PlaygroundViewModel(extensionRepository) as T
        }
    }
}

