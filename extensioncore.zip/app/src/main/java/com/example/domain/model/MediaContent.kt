package com.example.domain.model

enum class MediaType {
    MANGA,
    NOVEL,
    ANIME,
    NEWS
}

data class MediaItem(
    val id: String,
    val title: String,
    val coverUrl: String,
    val description: String = "",
    val author: String = "Unknown",
    val status: String = "Ongoing",
    val genres: List<String> = emptyList(),
    val sourceId: String,
    val url: String = "",
    val mediaType: MediaType = MediaType.MANGA,
    val rating: Float = 4.5f
)

data class Chapter(
    val id: String,
    val mediaId: String,
    val title: String,
    val chapterNumber: Float,
    val dateUpload: String = "",
    val url: String = "",
    val scanlator: String = ""
)

data class PageContent(
    val pageNumber: Int,
    val imageUrl: String = "",
    val textContent: String = "",
    val videoUrl: String = ""
)

data class HistoryEntityModel(
    val chapterId: String,
    val mediaId: String,
    val mediaTitle: String,
    val chapterTitle: String,
    val readAt: Long,
    val lastPage: Int
)
