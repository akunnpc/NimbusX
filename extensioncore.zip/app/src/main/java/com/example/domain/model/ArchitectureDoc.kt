package com.example.domain.model

data class ArchitectureDocTopic(
    val id: String,
    val title: String,
    val category: String,
    val summary: String,
    val detailedContent: String,
    val diagramAscii: String = "",
    val codeSnippet: String = ""
)

data class ArchitectureComparison(
    val approach: String,
    val securityScore: String,
    val performanceScore: String,
    val developerExperience: String,
    val updateFlexibility: String,
    val pros: List<String>,
    val cons: List<String>
)
