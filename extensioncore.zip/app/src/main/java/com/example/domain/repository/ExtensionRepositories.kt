package com.example.domain.repository

import com.example.domain.model.Chapter
import com.example.domain.model.Extension
import com.example.domain.model.ExtensionRepo
import com.example.domain.model.HistoryEntityModel
import com.example.domain.model.MediaItem
import com.example.domain.model.PageContent
import kotlinx.coroutines.flow.Flow

interface ExtensionRepository {
    fun getInstalledExtensions(): Flow<List<Extension>>
    suspend fun installExtensionFromPayload(payload: String, repoUrl: String = ""): Result<Extension>
    suspend fun installExtensionFromUrl(url: String): Result<Extension>
    suspend fun toggleExtension(pkgName: String, isEnabled: Boolean)
    suspend fun deleteExtension(pkgName: String)
    suspend fun updateExtension(extension: Extension): Result<Extension>
    
    fun getRepositories(): Flow<List<ExtensionRepo>>
    suspend fun addRepository(name: String, url: String, description: String)
    suspend fun deleteRepository(id: String)
    suspend fun fetchAvailableExtensionsFromRepo(repoUrl: String): List<Extension>
}

interface SourceRepository {
    suspend fun getPopular(extension: Extension, page: Int = 1): List<MediaItem>
    suspend fun search(extension: Extension, query: String, page: Int = 1): List<MediaItem>
    suspend fun getDetails(extension: Extension, mediaId: String): MediaItem
    suspend fun getChapters(extension: Extension, mediaId: String): List<Chapter>
    suspend fun getPages(extension: Extension, chapterId: String): List<PageContent>
}

interface LibraryRepository {
    fun getLibraryItems(): Flow<List<MediaItem>>
    fun isBookmarked(id: String): Flow<Boolean>
    suspend fun toggleBookmark(mediaItem: MediaItem)
    fun getHistory(): Flow<List<HistoryEntityModel>>
    suspend fun recordHistory(chapterId: String, mediaId: String, mediaTitle: String, chapterTitle: String, lastPage: Int)
}
