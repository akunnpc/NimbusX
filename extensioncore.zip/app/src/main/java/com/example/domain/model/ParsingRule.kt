package com.example.domain.model

data class ParsingRule(
    val popularUrl: String = "",
    val searchUrl: String = "",
    val catalogSelector: String = "",
    val titleSelector: String = "",
    val coverSelector: String = "",
    val urlSelector: String = "",
    val detailsTitleSelector: String = "",
    val detailsDescSelector: String = "",
    val chaptersSelector: String = "",
    val chapterTitleSelector: String = "",
    val chapterUrlSelector: String = "",
    val pagesSelector: String = "",
    val pageUrlSelector: String = ""
)
