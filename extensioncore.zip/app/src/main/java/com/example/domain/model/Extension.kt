package com.example.domain.model

enum class ParserType {
    JSON_DSL,
    JS_ENGINE,
    DEX_APK
}

enum class ExtensionStatus {
    INSTALLED,
    UPDATE_AVAILABLE,
    DISABLED,
    SECURITY_ERROR
}

data class Extension(
    val id: String,
    val pkgName: String,
    val name: String,
    val versionCode: Int,
    val versionName: String,
    val lang: String,
    val iconUrl: String,
    val description: String,
    val author: String,
    val baseUrl: String,
    val parserType: ParserType,
    val status: ExtensionStatus = ExtensionStatus.INSTALLED,
    val isNsfw: Boolean = false,
    val signatureHash: String = "",
    val scriptContent: String = "", // JSON DSL or JS code
    val installedAt: Long = System.currentTimeMillis(),
    val repoUrl: String = ""
)

data class ExtensionRepo(
    val id: String,
    val name: String,
    val url: String,
    val description: String,
    val extensionCount: Int = 0
)
