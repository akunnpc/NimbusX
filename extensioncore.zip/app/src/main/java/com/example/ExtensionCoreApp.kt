package com.example

import android.app.Application
import com.example.data.extension.DynamicParserEngine
import com.example.data.local.AppDatabase
import com.example.data.repository.ExtensionRepositoryImpl
import com.example.data.repository.LibraryRepositoryImpl
import com.example.data.repository.SourceRepositoryImpl
import com.example.domain.repository.ExtensionRepository
import com.example.domain.repository.LibraryRepository
import com.example.domain.repository.SourceRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ExtensionCoreApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var extensionRepository: ExtensionRepository
        private set

    lateinit var sourceRepository: SourceRepository
        private set

    lateinit var libraryRepository: LibraryRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        
        val extRepoImpl = ExtensionRepositoryImpl(database.extensionDao())
        extensionRepository = extRepoImpl
        sourceRepository = SourceRepositoryImpl(DynamicParserEngine())
        libraryRepository = LibraryRepositoryImpl(database.libraryDao())

        // Initialize preset extensions on first launch
        CoroutineScope(Dispatchers.IO).launch {
            extRepoImpl.initializePresetsIfEmpty()
        }
    }
}
