package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark Color Palette
val SophisticatedBackground = Color(0xFF1A1C1E)
val SophisticatedSurface = Color(0xFF232429)
val SophisticatedSurfaceVariant = Color(0xFF2D2F36)
val SophisticatedOutline = Color(0xFF45474F)

val SophisticatedPrimary = Color(0xFFD0BCFF)
val SophisticatedOnPrimary = Color(0xFF381E72)
val SophisticatedPrimaryContainer = Color(0xFF4A4458)
val SophisticatedOnPrimaryContainer = Color(0xFFE8DEF8)

val SophisticatedSecondary = Color(0xFFCCC2DC)
val SophisticatedSecondaryContainer = Color(0xFF4A4458)
val SophisticatedOnSecondaryContainer = Color(0xFFE8DEF8)

val SophisticatedTertiary = Color(0xFFEFB8C8)
val SophisticatedTertiaryContainer = Color(0xFF633B48)

val SophisticatedOnBackground = Color(0xFFE2E2E6)
val SophisticatedOnSurface = Color(0xFFE2E2E6)
val SophisticatedOnSurfaceVariant = Color(0xFFC4C6D0)

val AccentSuccess = Color(0xFFC2E8C4)
val AccentWarning = Color(0xFFFFB4AB)
val AccentError = Color(0xFFFFB4AB)

