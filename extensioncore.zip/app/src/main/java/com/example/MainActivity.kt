package com.example

import android.os.Bundle
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Architecture
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.presentation.ui.docs.ArchitectureDocsScreen
import com.example.presentation.ui.docs.ArchitectureDocsViewModel
import com.example.presentation.ui.explore.ExploreScreen
import com.example.presentation.ui.explore.SourceBrowserViewModel
import com.example.presentation.ui.explore.SourceDetailScreen
import com.example.presentation.ui.explore.SourceDetailViewModel
import com.example.presentation.ui.extensions.ExtensionsScreen
import com.example.presentation.ui.extensions.ExtensionsViewModel
import com.example.presentation.ui.library.LibraryScreen
import com.example.presentation.ui.playground.PlaygroundScreen
import com.example.presentation.ui.playground.PlaygroundViewModel
import com.example.presentation.ui.reader.ReaderScreen
import com.example.presentation.ui.reader.ReaderViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        val app = application as ExtensionCoreApp

        setContent {
            MyApplicationTheme {
                val navController = rememberNavController()
                val snackbarHostState = remember { SnackbarHostState() }

                val extensionsViewModel: ExtensionsViewModel = viewModel(
                    factory = ExtensionsViewModel.Factory(app.extensionRepository)
                )
                val sourceBrowserViewModel: SourceBrowserViewModel = viewModel(
                    factory = SourceBrowserViewModel.Factory(app.extensionRepository, app.sourceRepository)
                )
                val sourceDetailViewModel: SourceDetailViewModel = viewModel(
                    factory = SourceDetailViewModel.Factory(app.extensionRepository, app.sourceRepository, app.libraryRepository)
                )
                val readerViewModel: ReaderViewModel = viewModel(
                    factory = ReaderViewModel.Factory(app.extensionRepository, app.sourceRepository, app.libraryRepository)
                )
                val playgroundViewModel: PlaygroundViewModel = viewModel(
                    factory = PlaygroundViewModel.Factory(app.extensionRepository)
                )
                val docsViewModel: ArchitectureDocsViewModel = viewModel()

                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                val showBottomBar = currentRoute in listOf(
                    NavRoutes.EXPLORE,
                    NavRoutes.EXTENSIONS,
                    NavRoutes.LIBRARY,
                    NavRoutes.PLAYGROUND,
                    NavRoutes.DOCS
                )

                Scaffold(
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    bottomBar = {
                        if (showBottomBar) {
                            NavigationBar {
                                navItems.forEach { item ->
                                    NavigationBarItem(
                                        selected = currentRoute == item.route,
                                        onClick = {
                                            navController.navigate(item.route) {
                                                popUpTo(navController.graph.findStartDestination().id) {
                                                    saveState = true
                                                }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        },
                                        icon = { Icon(item.icon, contentDescription = item.label) },
                                        label = { Text(item.label) }
                                    )
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = NavRoutes.EXPLORE,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(NavRoutes.EXPLORE) {
                            ExploreScreen(
                                viewModel = sourceBrowserViewModel,
                                onMediaClick = { item, pkg ->
                                    navController.navigate("${NavRoutes.DETAIL}/${item.id}/$pkg")
                                }
                            )
                        }

                        composable(NavRoutes.EXTENSIONS) {
                            ExtensionsScreen(
                                viewModel = extensionsViewModel,
                                snackbarHostState = snackbarHostState
                            )
                        }

                        composable(NavRoutes.LIBRARY) {
                            LibraryScreen(
                                libraryRepository = app.libraryRepository,
                                onMediaClick = { item ->
                                    navController.navigate("${NavRoutes.DETAIL}/${item.id}/${item.sourceId}")
                                }
                            )
                        }

                        composable(NavRoutes.PLAYGROUND) {
                            PlaygroundScreen(
                                viewModel = playgroundViewModel,
                                snackbarHostState = snackbarHostState
                            )
                        }

                        composable(NavRoutes.DOCS) {
                            ArchitectureDocsScreen(viewModel = docsViewModel)
                        }

                        composable(
                            route = "${NavRoutes.DETAIL}/{mediaId}/{pkgName}",
                            arguments = listOf(
                                navArgument("mediaId") { type = NavType.StringType },
                                navArgument("pkgName") { type = NavType.StringType }
                            )
                        ) { backStackEntry ->
                            val mediaId = backStackEntry.arguments?.getString("mediaId") ?: ""
                            val pkgName = backStackEntry.arguments?.getString("pkgName") ?: ""
                            SourceDetailScreen(
                                mediaId = mediaId,
                                pkgName = pkgName,
                                viewModel = sourceDetailViewModel,
                                onBack = { navController.popBackStack() },
                                onChapterClick = { chapter, pkg ->
                                    val encodedTitle = Uri.encode(chapter.title)
                                    navController.navigate("${NavRoutes.READER}/${chapter.id}/$mediaId/$pkg/$encodedTitle")
                                }
                            )
                        }

                        composable(
                            route = "${NavRoutes.READER}/{chapterId}/{mediaId}/{pkgName}/{chapterTitle}",
                            arguments = listOf(
                                navArgument("chapterId") { type = NavType.StringType },
                                navArgument("mediaId") { type = NavType.StringType },
                                navArgument("pkgName") { type = NavType.StringType },
                                navArgument("chapterTitle") { type = NavType.StringType }
                            )
                        ) { backStackEntry ->
                            val chapterId = backStackEntry.arguments?.getString("chapterId") ?: ""
                            val mediaId = backStackEntry.arguments?.getString("mediaId") ?: ""
                            val pkgName = backStackEntry.arguments?.getString("pkgName") ?: ""
                            val chapterTitle = Uri.decode(backStackEntry.arguments?.getString("chapterTitle") ?: "")
                            ReaderScreen(
                                chapterId = chapterId,
                                mediaId = mediaId,
                                pkgName = pkgName,
                                chapterTitle = chapterTitle,
                                viewModel = readerViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}

object NavRoutes {
    const val EXPLORE = "explore"
    const val EXTENSIONS = "extensions"
    const val LIBRARY = "library"
    const val PLAYGROUND = "playground"
    const val DOCS = "docs"
    const val DETAIL = "detail"
    const val READER = "reader"
}

data class NavItem(val label: String, val route: String, val icon: ImageVector)

val navItems = listOf(
    NavItem("Explore", NavRoutes.EXPLORE, Icons.Default.Explore),
    NavItem("Extensions", NavRoutes.EXTENSIONS, Icons.Default.Extension),
    NavItem("Library", NavRoutes.LIBRARY, Icons.Default.Bookmark),
    NavItem("Playground", NavRoutes.PLAYGROUND, Icons.Default.Code),
    NavItem("Docs", NavRoutes.DOCS, Icons.Default.Architecture)
)
