package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "installed_extensions")
data class InstalledExtensionEntity(
    @PrimaryKey val pkgName: String,
    val name: String,
    val versionCode: Int,
    val versionName: String,
    val lang: String,
    val iconUrl: String,
    val description: String,
    val author: String,
    val baseUrl: String,
    val parserType: String,
    val isEnabled: Boolean = true,
    val signatureHash: String = "",
    val scriptContent: String,
    val installedAt: Long = System.currentTimeMillis(),
    val repoUrl: String = ""
)

@Entity(tableName = "extension_repositories")
data class ExtensionRepoEntity(
    @PrimaryKey val id: String,
    val name: String,
    val url: String,
    val description: String,
    val extensionCount: Int = 0
)

@Entity(tableName = "library_items")
data class LibraryItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val coverUrl: String,
    val sourceId: String,
    val sourceName: String,
    val mediaType: String,
    val lastChapterRead: String = "",
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "read_history")
data class HistoryEntity(
    @PrimaryKey val chapterId: String,
    val mediaId: String,
    val mediaTitle: String,
    val chapterTitle: String,
    val readAt: Long = System.currentTimeMillis(),
    val lastPage: Int = 0
)
