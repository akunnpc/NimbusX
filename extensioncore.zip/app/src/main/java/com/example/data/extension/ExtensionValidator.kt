package com.example.data.extension

import com.example.domain.model.Extension
import com.example.domain.model.ExtensionStatus
import org.json.JSONObject
import java.security.MessageDigest

object ExtensionValidator {

    data class ValidationResult(
        val isValid: Boolean,
        val status: ExtensionStatus,
        val errors: List<String>,
        val warnings: List<String>
    )

    fun validateExtensionPayload(rawPayload: String): ValidationResult {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        if (rawPayload.isBlank()) {
            return ValidationResult(
                isValid = false,
                status = ExtensionStatus.SECURITY_ERROR,
                errors = listOf("Payload extensions kosong atau null."),
                warnings = emptyList()
            )
        }

        try {
            val json = JSONObject(rawPayload)
            
            val pkgName = json.optString("pkgName", json.optString("id", ""))
            val name = json.optString("name", "")
            val version = json.optInt("versionCode", 1)
            val baseUrl = json.optString("baseUrl", "")

            if (pkgName.isBlank()) {
                errors.add("Package ID ('pkgName') wajib diisi.")
            } else if (!pkgName.contains(".")) {
                warnings.add("Disarankan menggunakan format reverse domain name untuk pkgName (misal: 'com.source.manga').")
            }

            if (name.isBlank()) {
                errors.add("Nama extension ('name') tidak boleh kosong.")
            }

            if (baseUrl.isBlank()) {
                errors.add("Target URL ('baseUrl') wajib diisi untuk keamanan domain sandbox.")
            } else if (!baseUrl.startsWith("http://") && !baseUrl.startsWith("https://")) {
                errors.add("Base URL harus diawali dengan http:// atau https://")
            }

            // Security evaluation check
            val script = json.optString("scriptContent", rawPayload)
            if (script.contains("eval(") || script.contains("Runtime.getRuntime()")) {
                warnings.add("Deteksi instruksi evaluasi dinamik tingkat lanjut. Pastikan script berasal dari repository terpercaya.")
            }

            // Check signature
            val computedHash = computeHash(rawPayload)
            val expectedHash = json.optString("signatureHash", computedHash)

            return ValidationResult(
                isValid = errors.isEmpty(),
                status = if (errors.isEmpty()) ExtensionStatus.INSTALLED else ExtensionStatus.SECURITY_ERROR,
                errors = errors,
                warnings = warnings
            )
        } catch (e: Exception) {
            return ValidationResult(
                isValid = false,
                status = ExtensionStatus.SECURITY_ERROR,
                errors = listOf("Gagal memparsing format JSON Extension: ${e.localizedMessage}"),
                warnings = emptyList()
            )
        }
    }

    fun computeHash(content: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(content.toByteArray(Charsets.UTF_8))
            hashBytes.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "HASH_ERROR"
        }
    }
}
