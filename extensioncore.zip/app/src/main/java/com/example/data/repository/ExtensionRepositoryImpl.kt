package com.example.data.repository

import com.example.data.extension.ExtensionValidator
import com.example.data.extension.PresetExtensions
import com.example.data.local.dao.ExtensionDao
import com.example.data.local.entity.ExtensionRepoEntity
import com.example.data.local.entity.InstalledExtensionEntity
import com.example.domain.model.Extension
import com.example.domain.model.ExtensionRepo
import com.example.domain.model.ExtensionStatus
import com.example.domain.model.ParserType
import com.example.domain.repository.ExtensionRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.UUID

class ExtensionRepositoryImpl(
    private val extensionDao: ExtensionDao,
    private val okHttpClient: OkHttpClient = OkHttpClient()
) : ExtensionRepository {

    suspend fun initializePresetsIfEmpty() = withContext(Dispatchers.IO) {
        val currentList = extensionDao.getAllExtensions().first()
        if (currentList.isEmpty()) {
            PresetExtensions.PRESET_EXTENSIONS.forEach { ext ->
                extensionDao.insertOrUpdateExtension(ext.toEntity())
            }
            PresetExtensions.PRESET_REPOSITORIES.forEach { repo ->
                extensionDao.insertRepository(
                    ExtensionRepoEntity(
                        id = repo.id,
                        name = repo.name,
                        url = repo.url,
                        description = repo.description,
                        extensionCount = repo.extensionCount
                    )
                )
            }
        }
    }

    override fun getInstalledExtensions(): Flow<List<Extension>> {
        return extensionDao.getAllExtensions().map { list ->
            list.map { it.toDomain() }
        }
    }

    override suspend fun installExtensionFromPayload(payload: String, repoUrl: String): Result<Extension> = withContext(Dispatchers.IO) {
        try {
            val validation = ExtensionValidator.validateExtensionPayload(payload)
            if (!validation.isValid) {
                return@withContext Result.failure(Exception(validation.errors.joinToString("\n")))
            }

            val json = JSONObject(payload)
            val pkgName = json.optString("pkgName", "com.custom.ext_${System.currentTimeMillis()}")
            val name = json.optString("name", "Custom Extension")
            val versionCode = json.optInt("versionCode", 1)
            val versionName = json.optString("versionName", "1.0.0")
            val lang = json.optString("lang", "all")
            val iconUrl = json.optString("iconUrl", "https://picsum.photos/100/100?random=$pkgName")
            val description = json.optString("description", "Extension dinamis dari file/URL lokal.")
            val author = json.optString("author", "Developer")
            val baseUrl = json.optString("baseUrl", "https://example.com")
            val parserTypeStr = json.optString("parserType", "JSON_DSL")
            val parserType = try { ParserType.valueOf(parserTypeStr) } catch (e: Exception) { ParserType.JSON_DSL }

            val signatureHash = json.optString("signatureHash", ExtensionValidator.computeHash(payload))

            val entity = InstalledExtensionEntity(
                pkgName = pkgName,
                name = name,
                versionCode = versionCode,
                versionName = versionName,
                lang = lang,
                iconUrl = iconUrl,
                description = description,
                author = author,
                baseUrl = baseUrl,
                parserType = parserType.name,
                isEnabled = true,
                signatureHash = signatureHash,
                scriptContent = payload,
                installedAt = System.currentTimeMillis(),
                repoUrl = repoUrl
            )

            extensionDao.insertOrUpdateExtension(entity)
            Result.success(entity.toDomain())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun installExtensionFromUrl(url: String): Result<Extension> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url).build()
            val response = okHttpClient.newCall(request).execute()
            val body = response.body?.string() ?: throw Exception("Response body dari URL $url kosong.")
            installExtensionFromPayload(body, url)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun toggleExtension(pkgName: String, isEnabled: Boolean) {
        extensionDao.setExtensionEnabled(pkgName, isEnabled)
    }

    override suspend fun deleteExtension(pkgName: String) {
        extensionDao.deleteExtension(pkgName)
    }

    override suspend fun updateExtension(extension: Extension): Result<Extension> = withContext(Dispatchers.IO) {
        val updated = extension.copy(
            versionCode = extension.versionCode + 1,
            versionName = "${extension.versionCode / 100}.${(extension.versionCode % 100) / 10}.${extension.versionCode % 10 + 1}",
            status = ExtensionStatus.INSTALLED
        )
        extensionDao.insertOrUpdateExtension(updated.toEntity())
        Result.success(updated)
    }

    override fun getRepositories(): Flow<List<ExtensionRepo>> {
        return extensionDao.getAllRepositories().map { list ->
            list.map { ExtensionRepo(it.id, it.name, it.url, it.description, it.extensionCount) }
        }
    }

    override suspend fun addRepository(name: String, url: String, description: String) {
        extensionDao.insertRepository(
            ExtensionRepoEntity(
                id = UUID.randomUUID().toString(),
                name = name,
                url = url,
                description = description,
                extensionCount = 3
            )
        )
    }

    override suspend fun deleteRepository(id: String) {
        extensionDao.deleteRepository(id)
    }

    override suspend fun fetchAvailableExtensionsFromRepo(repoUrl: String): List<Extension> {
        return PresetExtensions.PRESET_EXTENSIONS
    }

    private fun InstalledExtensionEntity.toDomain(): Extension {
        return Extension(
            id = pkgName,
            pkgName = pkgName,
            name = name,
            versionCode = versionCode,
            versionName = versionName,
            lang = lang,
            iconUrl = iconUrl,
            description = description,
            author = author,
            baseUrl = baseUrl,
            parserType = try { ParserType.valueOf(parserType) } catch (e: Exception) { ParserType.JSON_DSL },
            status = if (isEnabled) ExtensionStatus.INSTALLED else ExtensionStatus.DISABLED,
            signatureHash = signatureHash,
            scriptContent = scriptContent,
            installedAt = installedAt,
            repoUrl = repoUrl
        )
    }

    private fun Extension.toEntity(): InstalledExtensionEntity {
        return InstalledExtensionEntity(
            pkgName = pkgName,
            name = name,
            versionCode = versionCode,
            versionName = versionName,
            lang = lang,
            iconUrl = iconUrl,
            description = description,
            author = author,
            baseUrl = baseUrl,
            parserType = parserType.name,
            isEnabled = status != ExtensionStatus.DISABLED,
            signatureHash = signatureHash,
            scriptContent = scriptContent,
            installedAt = installedAt,
            repoUrl = repoUrl
        )
    }
}
