package com.example.data.extension

import com.example.domain.model.ArchitectureComparison
import com.example.domain.model.ArchitectureDocTopic

object ArchitectureDocumentationProvider {

    val COMPARISONS = listOf(
        ArchitectureComparison(
            approach = "JSON DSL / Declarative Rules",
            securityScore = "10/10 (Sangat Aman)",
            performanceScore = "9.5/10 (Native Speed)",
            developerExperience = "8/10 (Declarative Config)",
            updateFlexibility = "10/10 (Instant OTA update)",
            pros = listOf(
                "Tidak ada eksekusi code arbitrer (No Code Execution)",
                "Dapat divalidasi dengan JSON Schema statis",
                "Performa luar biasa tinggi karena diparse oleh Native Kotlin Engine",
                "Sangat mudah di-update melalui URL JSON tanpa build APK"
            ),
            cons = listOf(
                "Terbatas pada logika deklaratif murni",
                "Sulit menangani alur otentikasi kompleks atau enkripsi token khusus"
            )
        ),
        ArchitectureComparison(
            approach = "JavaScript Engine (QuickJS / Duktape)",
            securityScore = "8.5/10 (Isolated Memory Sandbox)",
            performanceScore = "8/10 (JIT / Interpreted JS)",
            developerExperience = "9.5/10 (Standard Web JS Skills)",
            updateFlexibility = "10/10 (Instant OTA update)",
            pros = listOf(
                "Tingkat fleksibilitas sangat tinggi untuk penanganan API/HTML rumit",
                "Pengembang extension menggunakan JavaScript standar",
                "Isolasi sandbox memori independen tanpa akses ke Sistem Operasi Android",
                "Memungkinkan bypass challenge/decryption secara dinamis"
            ),
            cons = listOf(
                "Memerlukan Native C++ JNI bridge / WASM overhead",
                "Perlu kontrol ketat atas timeout & alokasi memori"
            )
        ),
        ArchitectureComparison(
            approach = "Dynamic Feature Module / APK DEX Loading (Tachiyomi Model)",
            securityScore = "6.5/10 (Memerlukan Verified Signature)",
            performanceScore = "10/10 (Compiled Native DEX Bytecode)",
            developerExperience = "7/10 (Standard Android Gradle Module)",
            updateFlexibility = "7.5/10 (Perlu re-compile APK extension)",
            pros = listOf(
                "Akses penuh ke ekosistem Kotlin/Java & OkHttp/Jsoup",
                "Kecepatan eksekusi compiled Bytecode tanpa overhead interpreter",
                "Dukungan penuh Android Toolchain"
            ),
            cons = listOf(
                "Resiko keamanan tinggi jika APK memuat malicious code (perlu signature check)",
                "Proses instalasi APK memerlukan izin INSTALL_PACKAGES / Unknown Sources"
            )
        )
    )

    val TOPICS = listOf(
        ArchitectureDocTopic(
            id = "topic_clean_arch",
            title = "1. Clean Architecture + MVVM Setup",
            category = "Core Architecture",
            summary = "Pemisahan tegas antara UI (Presentation), Logic (Domain), dan Data Source (Data Layer).",
            detailedContent = """
                Arsitektur ini membagi sistem menjadi 3 layer utama dengan aturan ketergantungan 1 arah (Dependency Rule):
                
                • Presentation Layer (Jetpack Compose + ViewModel):
                  Mengelola state UI secara reaktif menggunakan StateFlow. Tidak menyimpan bisnis logic parser.
                  
                • Domain Layer (UseCases + Models + Repository Interfaces):
                  Inti dari aplikasi yang berisi aturan bisnis murni. Bebas dari dependensi framework Android/Room/OkHttp.
                  
                • Data Layer (ExtensionManager + Room DB + DynamicParserEngine):
                  Bertanggung jawab memuat, mengunduh, mengevaluasi, dan menyimpan data extension secara lokal.
            """.trimIndent(),
            diagramAscii = """
┌────────────────────────────────────────────────────────┐
│                   PRESENTATION LAYER                   │
│   Composable UI ───► ViewModel (collectAsState)         │
└───────────────────────────┬────────────────────────────┘
                            │ (Observes UIState)
┌───────────────────────────▼────────────────────────────┐
│                      DOMAIN LAYER                      │
│   UseCases ◄───► Domain Models ◄───► Repository Interfaces│
└───────────────────────────▲────────────────────────────┘
                            │ (Implements Interfaces)
┌───────────────────────────┴────────────────────────────┐
│                       DATA LAYER                       │
│   ExtensionManager  │ Room Database  │ OkHttp Client   │
│   Validator         │ DAOs & Entities│ Parser Engine   │
└────────────────────────────────────────────────────────┘
            """.trimIndent()
        ),
        ArchitectureDocTopic(
            id = "topic_dynamic_loading",
            title = "2. Cara Extension Manager Memuat Plugin Dinamis",
            category = "Extension Engine",
            summary = "Proses registrasi, parsing JSON/JS bundle, dan instansiasi source parser tanpa recompilation.",
            detailedContent = """
                Alur Kerja Extension Manager saat memuat plugin:
                
                1. Ingestion: Extension diunduh melalui URL repository HTTP/HTTPS atau diimpor dari file JSON/JS lokal.
                2. Validation & Security Check: Checking signature hash SHA-256, schema JSON, serta whitelisting domain target.
                3. Registry Persistence: Extension yang lolos validasi disimpan ke dalam Room Database (tabel `installed_extensions`).
                4. Dynamic Engine Instantiation: Parser Engine memetakan deklarasi URL endpoint, CSS selectors, atau JS script ke dalam kontainer eksekusi runtime.
                5. Source Registry Exposure: Source otomatis muncul di UI Explore dan Search tanpa memicu restart aplikasi atau update APK.
            """.trimIndent(),
            codeSnippet = """
suspend fun installExtensionFromPayload(payload: String): Result<Extension> {
    val validation = ExtensionValidator.validateExtensionPayload(payload)
    if (!validation.isValid) return Result.failure(Exception(validation.errors))
    
    val entity = payload.toInstalledExtensionEntity()
    extensionDao.insertOrUpdateExtension(entity)
    return Result.success(entity.toDomain())
}
            """.trimIndent()
        ),
        ArchitectureDocTopic(
            id = "topic_updates_validation",
            title = "3. Sistem Update & Validasi Keamanan (Sandbox)",
            category = "Security & Lifecycle",
            summary = "Mekanisme verifikasi signature SHA-256, version checking, dan isolasi sandbox eksekusi.",
            detailedContent = """
                Setiap extension yang dimuat diperiksa dengan standar keamanan multi-lapis:
                
                • Version Check: Membandingkan versionCode versi baru dengan versi terpasang di Room DB.
                • SHA-256 Signature Verification: Memastikan payload extension belum dimodifikasi oleh pihak ketiga (Anti-Tampering).
                • Domain Sandbox: Extension hanya diizinkan melakukan request HTTP/HTTPS ke baseUrl yang terdaftar.
                • Static Code Audit: Deteksi otomatis terhadap instruksi berbahaya seperti `eval()` tak terisolasi atau panggilan Reflection.
            """.trimIndent()
        ),
        ArchitectureDocTopic(
            id = "topic_folder_structure",
            title = "4. Struktur Folder Project & Component Rationale",
            category = "Directory Design",
            summary = "Desain struktur package modular dan scalable yang memudahkan penambahan fitur & extension baru.",
            detailedContent = """
                com.example
                ├── data
                │   ├── extension/          # Core Extension Manager, Validator & Parser Engine
                │   ├── local/              # Room Database, DAOs, & Entities
                │   └── repository/         # Implementasi Concrete Repository
                ├── domain
                │   ├── model/              # Extension, MediaItem, Chapter, ArchitectureDoc
                │   └── repository/         # Interface Repository kontrak murni
                └── presentation
                    ├── components/         # Standard M3 Custom Cards, Chips & Navigation
                    ├── theme/              # ColorScheme, Typography & Custom Branding
                    └── ui/
                        ├── docs/           # Interactive Architecture Documentation View
                        ├── explore/        # Source Browser & Media Content Viewer
                        ├── extensions/     # Extension Manager & Repo Catalog Screen
                        ├── library/        # Bookmark Library & Reading History
                        ├── playground/     # Extension Live Sandbox & Developer IDE
                        └── reader/         # Interactive Chapter & Text Reader Engine
            """.trimIndent()
        )
    )
}
