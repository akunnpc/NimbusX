package com.example.data.extension

import com.example.domain.model.Extension
import com.example.domain.model.ExtensionRepo
import com.example.domain.model.ExtensionStatus
import com.example.domain.model.ParserType

object PresetExtensions {

    val PRESET_REPOSITORIES = listOf(
        ExtensionRepo(
            id = "repo_official",
            name = "Official Core Extension Repo",
            url = "https://raw.githubusercontent.com/extension-core/official-index/main/index.json",
            description = "Repository resmi untuk extension terverifikasi dengan tanda tangan digital SHA-256.",
            extensionCount = 4
        ),
        ExtensionRepo(
            id = "repo_community",
            name = "Community Extension Hub",
            url = "https://raw.githubusercontent.com/extension-core/community-hub/main/index.json",
            description = "Repository komunitas pihak ketiga untuk parser tambahan web novel dan komik.",
            extensionCount = 6
        )
    )

    val PRESET_EXTENSIONS = listOf(
        Extension(
            id = "ext_manganexus",
            pkgName = "com.extension.manganexus",
            name = "MangaNexus Source",
            versionCode = 102,
            versionName = "1.0.2",
            lang = "id/en",
            iconUrl = "https://picsum.photos/100/100?random=manganexus",
            description = "Parser komik & manga Indonesia dengan dukungan JSON DSL cepat & anti-Cloudflare.",
            author = "NEXUS Devs",
            baseUrl = "https://api.manganexus.org",
            parserType = ParserType.JSON_DSL,
            status = ExtensionStatus.INSTALLED,
            isNsfw = false,
            signatureHash = "a3f8921c29e4d010f92",
            scriptContent = """
            {
              "pkgName": "com.extension.manganexus",
              "name": "MangaNexus Source",
              "versionCode": 102,
              "baseUrl": "https://api.manganexus.org",
              "items": [
                {
                  "id": "mn_solo_leveling",
                  "title": "Solo Leveling: Arise",
                  "coverUrl": "https://picsum.photos/300/400?random=solo",
                  "description": "Sung Jinwoo diangkat menjadi Shadow Monarch dalam petualangan melintasi Dungeon berbahaya.",
                  "author": "Chugong",
                  "genres": ["Action", "Fantasy", "System"]
                },
                {
                  "id": "mn_one_piece",
                  "title": "One Piece Digital Color",
                  "coverUrl": "https://picsum.photos/300/400?random=onepiece",
                  "description": "Luffy dan Bajak Laut Topi Jerami berlayar mencari harta karun legendaris One Piece.",
                  "author": "Eiichiro Oda",
                  "genres": ["Action", "Adventure", "Shounen"]
                },
                {
                  "id": "mn_chainsaw_man",
                  "title": "Chainsaw Man",
                  "coverUrl": "https://picsum.photos/300/400?random=csm",
                  "description": "Denji membuat perjanjian dengan Iblis Gergaji Mesin Pochita untuk memburu iblis jahat.",
                  "author": "Tatsuki Fujimoto",
                  "genres": ["Action", "Dark Fantasy", "Horror"]
                },
                {
                  "id": "mn_jujutsu_kaisen",
                  "title": "Jujutsu Kaisen",
                  "coverUrl": "https://picsum.photos/300/400?random=jjk",
                  "description": "Itadori Yuji memakan jari Ryomen Sukuna dan masuk ke dalam dunia Penyihir Jujutsu.",
                  "author": "Gege Akutami",
                  "genres": ["Action", "Supernatural"]
                }
              ],
              "mockChapters": [
                { "id": "mn_solo_ch1", "title": "Chapter 200: Kebangkitan Raja Bayangan", "number": 200.0, "date": "2026-07-20" },
                { "id": "mn_solo_ch2", "title": "Chapter 199: Pertempuran Antar Monarki", "number": 199.0, "date": "2026-07-13" },
                { "id": "mn_solo_ch3", "title": "Chapter 198: Gerbang S-Rank Raksasa", "number": 198.0, "date": "2026-07-06" }
              ]
            }
            """.trimIndent()
        ),
        Extension(
            id = "ext_webnovel",
            pkgName = "com.extension.webnovel",
            name = "WebNovel World",
            versionCode = 100,
            versionName = "1.0.0",
            lang = "id",
            iconUrl = "https://picsum.photos/100/100?random=webnovel",
            description = "Parser novel terjemahan Indonesia & Inggris dengan mode membaca teks nyaman.",
            author = "Novelist Group",
            baseUrl = "https://webnovel.world",
            parserType = ParserType.JS_ENGINE,
            status = ExtensionStatus.INSTALLED,
            isNsfw = false,
            signatureHash = "b871239cd1092e01a11",
            scriptContent = """
            {
              "pkgName": "com.extension.webnovel",
              "name": "WebNovel World",
              "versionCode": 100,
              "baseUrl": "https://webnovel.world",
              "items": [
                {
                  "id": "wn_lord_mysteries",
                  "title": "Lord of the Mysteries",
                  "coverUrl": "https://picsum.photos/300/400?random=lotm",
                  "description": "Zhou Mingrui bertransmigrasi ke dunia Victoria Steampunk yang penuh misteri Eldritch dan ramuan urutan.",
                  "author": "Cuttlefish That Loves Diving",
                  "genres": ["Mystery", "Steampunk", "Supernatural"]
                },
                {
                  "id": "wn_shadow_slave",
                  "title": "Shadow Slave",
                  "coverUrl": "https://picsum.photos/300/400?random=ss",
                  "description": "Sunny yang hidup miskin terjangkit Nightmare Spell dan mendapatkan Aspect Slave.",
                  "author": "Guiltythree",
                  "genres": ["Fantasy", "Action", "Adventure"]
                },
                {
                  "id": "wn_orv",
                  "title": "Omniscient Reader's Viewpoint",
                  "coverUrl": "https://picsum.photos/300/400?random=orv",
                  "description": "Kim Dokja menjadi satu-satunya pembaca novel apocalypse 3,000 bab yang mendadak jadi kenyataan.",
                  "author": "Sing Shong",
                  "genres": ["System", "Psychological", "Action"]
                }
              ]
            }
            """.trimIndent()
        ),
        Extension(
            id = "ext_animepulse",
            pkgName = "com.extension.animepulse",
            name = "AnimePulse Stream",
            versionCode = 201,
            versionName = "2.0.1",
            lang = "en",
            iconUrl = "https://picsum.photos/100/100?random=animepulse",
            description = "Extension streaming anime dengan metadata episode & subtitle otomatis.",
            author = "Pulse Core",
            baseUrl = "https://animepulse.stream",
            parserType = ParserType.JSON_DSL,
            status = ExtensionStatus.INSTALLED,
            isNsfw = false,
            signatureHash = "c928734e0911293a",
            scriptContent = """
            {
              "pkgName": "com.extension.animepulse",
              "name": "AnimePulse Stream",
              "versionCode": 201,
              "baseUrl": "https://animepulse.stream",
              "items": [
                {
                  "id": "ap_frieren",
                  "title": "Frieren: Beyond Journey's End",
                  "coverUrl": "https://picsum.photos/300/400?random=frieren",
                  "description": "Penyihir Elf Frieren merenungkan arti kehidupan manusia setelah pahlawan Himmer meninggal.",
                  "author": "Madhouse",
                  "genres": ["Fantasy", "Slice of Life", "Drama"]
                },
                {
                  "id": "ap_demon_slayer",
                  "title": "Demon Slayer: Hashira Training",
                  "coverUrl": "https://picsum.photos/300/400?random=demonslayer",
                  "description": "Tanjiro dan para pemburu iblis berlatih keras bersama Hashira sebelum pertempuran di Infinity Castle.",
                  "author": "ufotable",
                  "genres": ["Action", "Historical", "Supernatural"]
                }
              ]
            }
            """.trimIndent()
        ),
        Extension(
            id = "ext_technews",
            pkgName = "com.extension.technews",
            name = "Tech & Developer Feed",
            versionCode = 110,
            versionName = "1.1.0",
            lang = "id/en",
            iconUrl = "https://picsum.photos/100/100?random=technews",
            description = "Parser REST API portal berita teknologi & artikel software engineering Android.",
            author = "DevCommunity",
            baseUrl = "https://technews.dev",
            parserType = ParserType.JSON_DSL,
            status = ExtensionStatus.INSTALLED,
            isNsfw = false,
            signatureHash = "d872134aa8823f",
            scriptContent = """
            {
              "pkgName": "com.extension.technews",
              "name": "Tech & Developer Feed",
              "versionCode": 110,
              "baseUrl": "https://technews.dev",
              "items": [
                {
                  "id": "tn_clean_arch",
                  "title": "Clean Architecture & Dynamic Plugin Design in Android 2026",
                  "coverUrl": "https://picsum.photos/300/400?random=tech1",
                  "description": "Panduan lengkap merancang Extension Manager dynamic loading menggunakan Kotlin & Jetpack Compose.",
                  "author": "Google Dev Team",
                  "genres": ["Android", "Architecture", "Kotlin"]
                },
                {
                  "id": "tn_quickjs",
                  "title": "Sandboxing JavaScript Engine on Mobile via QuickJS Wasm",
                  "coverUrl": "https://picsum.photos/300/400?random=tech2",
                  "description": "Keamanan eksekusi script untrusted dalam kontainer sandbox memori terbatas.",
                  "author": "Security Engineering",
                  "genres": ["Security", "WebAssembly", "JavaScript"]
                }
              ]
            }
            """.trimIndent()
        )
    )
}
