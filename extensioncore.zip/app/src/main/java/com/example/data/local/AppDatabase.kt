package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.ExtensionDao
import com.example.data.local.dao.LibraryDao
import com.example.data.local.entity.ExtensionRepoEntity
import com.example.data.local.entity.HistoryEntity
import com.example.data.local.entity.InstalledExtensionEntity
import com.example.data.local.entity.LibraryItemEntity

@Database(
    entities = [
        InstalledExtensionEntity::class,
        ExtensionRepoEntity::class,
        LibraryItemEntity::class,
        HistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun extensionDao(): ExtensionDao
    abstract fun libraryDao(): LibraryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "extension_core.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
