package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.ExtensionRepoEntity
import com.example.data.local.entity.HistoryEntity
import com.example.data.local.entity.InstalledExtensionEntity
import com.example.data.local.entity.LibraryItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ExtensionDao {
    @Query("SELECT * FROM installed_extensions ORDER BY name ASC")
    fun getAllExtensions(): Flow<List<InstalledExtensionEntity>>

    @Query("SELECT * FROM installed_extensions WHERE pkgName = :pkgName LIMIT 1")
    suspend fun getExtensionByPkg(pkgName: String): InstalledExtensionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateExtension(extension: InstalledExtensionEntity)

    @Query("UPDATE installed_extensions SET isEnabled = :isEnabled WHERE pkgName = :pkgName")
    suspend fun setExtensionEnabled(pkgName: String, isEnabled: Boolean)

    @Query("DELETE FROM installed_extensions WHERE pkgName = :pkgName")
    suspend fun deleteExtension(pkgName: String)

    @Query("SELECT * FROM extension_repositories ORDER BY name ASC")
    fun getAllRepositories(): Flow<List<ExtensionRepoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepository(repo: ExtensionRepoEntity)

    @Query("DELETE FROM extension_repositories WHERE id = :id")
    suspend fun deleteRepository(id: String)
}

@Dao
interface LibraryDao {
    @Query("SELECT * FROM library_items ORDER BY addedAt DESC")
    fun getLibraryItems(): Flow<List<LibraryItemEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM library_items WHERE id = :id)")
    fun isBookmarked(id: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLibraryItem(item: LibraryItemEntity)

    @Query("DELETE FROM library_items WHERE id = :id")
    suspend fun deleteLibraryItem(id: String)

    @Query("SELECT * FROM read_history ORDER BY readAt DESC")
    fun getHistory(): Flow<List<HistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun recordHistory(history: HistoryEntity)
}
