package com.example.data.repository

import com.example.data.local.dao.LibraryDao
import com.example.data.local.entity.HistoryEntity
import com.example.data.local.entity.LibraryItemEntity
import com.example.domain.model.HistoryEntityModel
import com.example.domain.model.MediaItem
import com.example.domain.model.MediaType
import com.example.domain.repository.LibraryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class LibraryRepositoryImpl(
    private val libraryDao: LibraryDao
) : LibraryRepository {

    override fun getLibraryItems(): Flow<List<MediaItem>> {
        return libraryDao.getLibraryItems().map { list ->
            list.map { entity ->
                MediaItem(
                    id = entity.id,
                    title = entity.title,
                    coverUrl = entity.coverUrl,
                    sourceId = entity.sourceId,
                    mediaType = try { MediaType.valueOf(entity.mediaType) } catch (e: Exception) { MediaType.MANGA }
                )
            }
        }
    }

    override fun isBookmarked(id: String): Flow<Boolean> {
        return libraryDao.isBookmarked(id)
    }

    override suspend fun toggleBookmark(mediaItem: MediaItem) {
        val currentlyBookmarked = libraryDao.isBookmarked(mediaItem.id).first()
        if (currentlyBookmarked) {
            libraryDao.deleteLibraryItem(mediaItem.id)
        } else {
            libraryDao.insertLibraryItem(
                LibraryItemEntity(
                    id = mediaItem.id,
                    title = mediaItem.title,
                    coverUrl = mediaItem.coverUrl,
                    sourceId = mediaItem.sourceId,
                    sourceName = "Source",
                    mediaType = mediaItem.mediaType.name,
                    addedAt = System.currentTimeMillis()
                )
            )
        }
    }

    override fun getHistory(): Flow<List<HistoryEntityModel>> {
        return libraryDao.getHistory().map { list ->
            list.map { entity ->
                HistoryEntityModel(
                    chapterId = entity.chapterId,
                    mediaId = entity.mediaId,
                    mediaTitle = entity.mediaTitle,
                    chapterTitle = entity.chapterTitle,
                    readAt = entity.readAt,
                    lastPage = entity.lastPage
                )
            }
        }
    }

    override suspend fun recordHistory(
        chapterId: String,
        mediaId: String,
        mediaTitle: String,
        chapterTitle: String,
        lastPage: Int
    ) {
        libraryDao.recordHistory(
            HistoryEntity(
                chapterId = chapterId,
                mediaId = mediaId,
                mediaTitle = mediaTitle,
                chapterTitle = chapterTitle,
                readAt = System.currentTimeMillis(),
                lastPage = lastPage
            )
        )
    }
}
