package com.example.data.repository

import com.example.data.extension.DynamicParserEngine
import com.example.domain.model.Chapter
import com.example.domain.model.Extension
import com.example.domain.model.MediaItem
import com.example.domain.model.PageContent
import com.example.domain.repository.SourceRepository

class SourceRepositoryImpl(
    private val parserEngine: DynamicParserEngine = DynamicParserEngine()
) : SourceRepository {

    override suspend fun getPopular(extension: Extension, page: Int): List<MediaItem> {
        return parserEngine.parsePopular(extension, page)
    }

    override suspend fun search(extension: Extension, query: String, page: Int): List<MediaItem> {
        return parserEngine.search(extension, query, page)
    }

    override suspend fun getDetails(extension: Extension, mediaId: String): MediaItem {
        return parserEngine.parseDetails(extension, mediaId)
    }

    override suspend fun getChapters(extension: Extension, mediaId: String): List<Chapter> {
        return parserEngine.parseChapters(extension, mediaId)
    }

    override suspend fun getPages(extension: Extension, chapterId: String): List<PageContent> {
        return parserEngine.parsePages(extension, chapterId)
    }
}
