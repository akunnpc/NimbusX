package com.example.presentation.ui.docs

import androidx.lifecycle.ViewModel
import com.example.data.extension.ArchitectureDocumentationProvider
import com.example.domain.model.ArchitectureComparison
import com.example.domain.model.ArchitectureDocTopic
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ArchitectureDocsViewModel : ViewModel() {

    val topics: List<ArchitectureDocTopic> = ArchitectureDocumentationProvider.TOPICS
    val comparisons: List<ArchitectureComparison> = ArchitectureDocumentationProvider.COMPARISONS

    private val _selectedTopic = MutableStateFlow<ArchitectureDocTopic>(topics.first())
    val selectedTopic: StateFlow<ArchitectureDocTopic> = _selectedTopic.asStateFlow()

    fun selectTopic(topic: ArchitectureDocTopic) {
        _selectedTopic.value = topic
    }
}
