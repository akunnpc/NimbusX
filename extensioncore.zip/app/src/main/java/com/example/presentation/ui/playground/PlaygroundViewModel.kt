package com.example.presentation.ui.playground

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.extension.DynamicParserEngine
import com.example.data.extension.ExtensionValidator
import com.example.domain.model.Extension
import com.example.domain.model.ExtensionStatus
import com.example.domain.model.MediaItem
import com.example.domain.model.ParserType
import com.example.domain.repository.ExtensionRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject

class PlaygroundViewModel(
    private val extensionRepository: ExtensionRepository,
    private val parserEngine: DynamicParserEngine = DynamicParserEngine()
) : ViewModel() {

    val sampleScript = """
    {
      "pkgName": "com.developer.sandbox_extension",
      "name": "Sandbox Custom Source",
      "versionCode": 100,
      "versionName": "1.0.0",
      "lang": "id",
      "iconUrl": "https://picsum.photos/100/100?random=sandbox",
      "description": "Custom extension yang dibuat secara live via Developer Sandbox.",
      "author": "You (Dev)",
      "baseUrl": "https://api.sandbox-demo.dev",
      "parserType": "JSON_DSL",
      "items": [
        {
          "id": "sb_item_1",
          "title": "Custom Extension Content A",
          "coverUrl": "https://picsum.photos/300/400?random=sb1",
          "description": "Item hasil evaluasi parser engine dinamis secara realtime di sandbox memori.",
          "author": "Playground Engine",
          "genres": ["Custom", "Testing", "Dynamic"]
        },
        {
          "id": "sb_item_2",
          "title": "Custom Extension Content B",
          "coverUrl": "https://picsum.photos/300/400?random=sb2",
          "description": "Item kedua yang memverifikasi isolasi sandbox dan skema JSON Validator.",
          "author": "Playground Engine",
          "genres": ["Sandbox", "Kotlin"]
        }
      ]
    }
    """.trimIndent()

    private val _scriptCode = MutableStateFlow(sampleScript)
    val scriptCode: StateFlow<String> = _scriptCode.asStateFlow()

    private val _validationResult = MutableStateFlow<ExtensionValidator.ValidationResult?>(null)
    val validationResult: StateFlow<ExtensionValidator.ValidationResult?> = _validationResult.asStateFlow()

    private val _parsedItems = MutableStateFlow<List<MediaItem>>(emptyList())
    val parsedItems: StateFlow<List<MediaItem>> = _parsedItems.asStateFlow()

    private val _isExecuting = MutableStateFlow(false)
    val isExecuting: StateFlow<Boolean> = _isExecuting.asStateFlow()

    private val _messageEvent = MutableSharedFlow<String>()
    val messageEvent: SharedFlow<String> = _messageEvent.asSharedFlow()

    fun updateScriptCode(newCode: String) {
        _scriptCode.value = newCode
    }

    fun validateAndRunTest() {
        val code = _scriptCode.value
        val validation = ExtensionValidator.validateExtensionPayload(code)
        _validationResult.value = validation

        if (validation.isValid) {
            viewModelScope.launch {
                _isExecuting.value = true
                try {
                    val json = JSONObject(code)
                    val dummyExt = Extension(
                        id = json.optString("pkgName", "com.custom.sandbox"),
                        pkgName = json.optString("pkgName", "com.custom.sandbox"),
                        name = json.optString("name", "Sandbox Test Source"),
                        versionCode = json.optInt("versionCode", 1),
                        versionName = json.optString("versionName", "1.0.0"),
                        lang = json.optString("lang", "id"),
                        iconUrl = json.optString("iconUrl", ""),
                        description = json.optString("description", ""),
                        author = json.optString("author", "Dev"),
                        baseUrl = json.optString("baseUrl", "https://example.com"),
                        parserType = ParserType.JSON_DSL,
                        status = ExtensionStatus.INSTALLED,
                        scriptContent = code
                    )

                    val results = parserEngine.parsePopular(dummyExt)
                    _parsedItems.value = results
                    _messageEvent.emit("Pengujian Sandbox Berhasil! Menemukan ${results.size} item hasil parsing.")
                } catch (e: Exception) {
                    _messageEvent.emit("Gagal Eksekusi: ${e.localizedMessage}")
                } finally {
                    _isExecuting.value = false
                }
            }
        } else {
            viewModelScope.launch {
                _messageEvent.emit("Validasi Gagal! Periksa tab pesan kesalahan.")
            }
        }
    }

    fun installScriptAsExtension() {
        val code = _scriptCode.value
        viewModelScope.launch {
            _isExecuting.value = true
            val result = extensionRepository.installExtensionFromPayload(code)
            _isExecuting.value = false
            result.onSuccess {
                _messageEvent.emit("Extension ${it.name} berhasil terinstall ke Extension Manager!")
            }.onFailure {
                _messageEvent.emit("Gagal menginstall: ${it.localizedMessage}")
            }
        }
    }

    class Factory(private val extensionRepository: ExtensionRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return PlaygroundViewModel(extensionRepository) as T
        }
    }
}
