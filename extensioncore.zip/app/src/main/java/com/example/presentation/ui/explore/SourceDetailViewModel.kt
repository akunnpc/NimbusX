package com.example.presentation.ui.explore

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.model.Chapter
import com.example.domain.model.Extension
import com.example.domain.model.MediaItem
import com.example.domain.repository.ExtensionRepository
import com.example.domain.repository.LibraryRepository
import com.example.domain.repository.SourceRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class SourceDetailViewModel(
    private val extensionRepository: ExtensionRepository,
    private val sourceRepository: SourceRepository,
    private val libraryRepository: LibraryRepository
) : ViewModel() {

    private val _mediaItem = MutableStateFlow<MediaItem?>(null)
    val mediaItem: StateFlow<MediaItem?> = _mediaItem.asStateFlow()

    private val _chapters = MutableStateFlow<List<Chapter>>(emptyList())
    val chapters: StateFlow<List<Chapter>> = _chapters.asStateFlow()

    private val _isBookmarked = MutableStateFlow(false)
    val isBookmarked: StateFlow<Boolean> = _isBookmarked.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    fun loadDetails(mediaId: String, pkgName: String) {
        viewModelScope.launch {
            _isLoading.value = true
            val extensions = extensionRepository.getInstalledExtensions().first()
            val ext = extensions.find { it.pkgName == pkgName } ?: extensions.firstOrNull()
            
            if (ext != null) {
                val detail = sourceRepository.getDetails(ext, mediaId)
                val chapterList = sourceRepository.getChapters(ext, mediaId)
                _mediaItem.value = detail
                _chapters.value = chapterList
                
                libraryRepository.isBookmarked(mediaId).collect {
                    _isBookmarked.value = it
                }
            }
            _isLoading.value = false
        }
    }

    fun toggleBookmark() {
        val item = _mediaItem.value ?: return
        viewModelScope.launch {
            libraryRepository.toggleBookmark(item)
        }
    }

    class Factory(
        private val extensionRepository: ExtensionRepository,
        private val sourceRepository: SourceRepository,
        private val libraryRepository: LibraryRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SourceDetailViewModel(extensionRepository, sourceRepository, libraryRepository) as T
        }
    }
}
