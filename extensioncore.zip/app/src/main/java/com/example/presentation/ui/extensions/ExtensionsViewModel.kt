package com.example.presentation.ui.extensions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.model.Extension
import com.example.domain.model.ExtensionRepo
import com.example.domain.repository.ExtensionRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ExtensionsViewModel(
    private val extensionRepository: ExtensionRepository
) : ViewModel() {

    val installedExtensions: StateFlow<List<Extension>> = extensionRepository.getInstalledExtensions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val repositories: StateFlow<List<ExtensionRepo>> = extensionRepository.getRepositories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _messageEvent = MutableSharedFlow<String>()
    val messageEvent: SharedFlow<String> = _messageEvent.asSharedFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    fun toggleExtension(pkgName: String, isEnabled: Boolean) {
        viewModelScope.launch {
            extensionRepository.toggleExtension(pkgName, isEnabled)
            _messageEvent.emit(if (isEnabled) "Extension diaktifkan." else "Extension dinonaktifkan.")
        }
    }

    fun deleteExtension(pkgName: String) {
        viewModelScope.launch {
            extensionRepository.deleteExtension(pkgName)
            _messageEvent.emit("Extension berhasil dihapus.")
        }
    }

    fun updateExtension(extension: Extension) {
        viewModelScope.launch {
            _isProcessing.value = true
            val result = extensionRepository.updateExtension(extension)
            _isProcessing.value = false
            result.onSuccess {
                _messageEvent.emit("Extension ${it.name} berhasil diperbarui ke v${it.versionName}")
            }.onFailure {
                _messageEvent.emit("Gagal memperbarui extension: ${it.localizedMessage}")
            }
        }
    }

    fun installFromPayload(payload: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            val result = extensionRepository.installExtensionFromPayload(payload)
            _isProcessing.value = false
            result.onSuccess {
                _messageEvent.emit("Extension ${it.name} berhasil terinstall!")
            }.onFailure {
                _messageEvent.emit("Validasi Gagal: ${it.localizedMessage}")
            }
        }
    }

    fun installFromUrl(url: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            val result = extensionRepository.installExtensionFromUrl(url)
            _isProcessing.value = false
            result.onSuccess {
                _messageEvent.emit("Extension ${it.name} berhasil diunduh & terinstall!")
            }.onFailure {
                _messageEvent.emit("Gagal mengunduh extension dari URL: ${it.localizedMessage}")
            }
        }
    }

    fun addRepository(name: String, url: String, desc: String) {
        viewModelScope.launch {
            extensionRepository.addRepository(name, url, desc)
            _messageEvent.emit("Repository baru ditambahkan.")
        }
    }

    fun deleteRepository(id: String) {
        viewModelScope.launch {
            extensionRepository.deleteRepository(id)
            _messageEvent.emit("Repository dihapus.")
        }
    }

    class Factory(private val extensionRepository: ExtensionRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ExtensionsViewModel(extensionRepository) as T
        }
    }
}
