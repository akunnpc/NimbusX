package com.example.presentation.ui.reader

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.model.Extension
import com.example.domain.model.PageContent
import com.example.domain.repository.ExtensionRepository
import com.example.domain.repository.LibraryRepository
import com.example.domain.repository.SourceRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class ReaderViewModel(
    private val extensionRepository: ExtensionRepository,
    private val sourceRepository: SourceRepository,
    private val libraryRepository: LibraryRepository
) : ViewModel() {

    private val _pages = MutableStateFlow<List<PageContent>>(emptyList())
    val pages: StateFlow<List<PageContent>> = _pages.asStateFlow()

    private val _currentPage = MutableStateFlow(1)
    val currentPage: StateFlow<Int> = _currentPage.asStateFlow()

    private val _chapterTitle = MutableStateFlow("")
    val chapterTitle: StateFlow<String> = _chapterTitle.asStateFlow()

    private val _mediaTitle = MutableStateFlow("")
    val mediaTitle: StateFlow<String> = _mediaTitle.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    fun loadChapter(chapterId: String, mediaId: String, pkgName: String, title: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _chapterTitle.value = title
            _mediaTitle.value = "Media $mediaId"
            
            val extensions = extensionRepository.getInstalledExtensions().first()
            val ext = extensions.find { it.pkgName == pkgName } ?: extensions.firstOrNull()

            if (ext != null) {
                val pageList = sourceRepository.getPages(ext, chapterId)
                _pages.value = pageList
                libraryRepository.recordHistory(
                    chapterId = chapterId,
                    mediaId = mediaId,
                    mediaTitle = _mediaTitle.value,
                    chapterTitle = title,
                    lastPage = 1
                )
            }
            _isLoading.value = false
        }
    }

    fun onPageChanged(page: Int) {
        _currentPage.value = page
    }

    class Factory(
        private val extensionRepository: ExtensionRepository,
        private val sourceRepository: SourceRepository,
        private val libraryRepository: LibraryRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ReaderViewModel(extensionRepository, sourceRepository, libraryRepository) as T
        }
    }
}
