package com.example.presentation.ui.explore

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.model.Extension
import com.example.domain.model.MediaItem
import com.example.domain.repository.ExtensionRepository
import com.example.domain.repository.SourceRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SourceBrowserViewModel(
    private val extensionRepository: ExtensionRepository,
    private val sourceRepository: SourceRepository
) : ViewModel() {

    val activeExtensions: StateFlow<List<Extension>> = extensionRepository.getInstalledExtensions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedExtension = MutableStateFlow<Extension?>(null)
    val selectedExtension: StateFlow<Extension?> = _selectedExtension.asStateFlow()

    private val _mediaItems = MutableStateFlow<List<MediaItem>>(emptyList())
    val mediaItems: StateFlow<List<MediaItem>> = _mediaItems.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    fun selectExtension(extension: Extension) {
        _selectedExtension.value = extension
        loadPopularContent(extension)
    }

    fun search(query: String) {
        _searchQuery.value = query
        val ext = _selectedExtension.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            _mediaItems.value = sourceRepository.search(ext, query)
            _isLoading.value = false
        }
    }

    fun refresh() {
        val ext = _selectedExtension.value ?: return
        loadPopularContent(ext)
    }

    private fun loadPopularContent(extension: Extension) {
        viewModelScope.launch {
            _isLoading.value = true
            _mediaItems.value = sourceRepository.getPopular(extension)
            _isLoading.value = false
        }
    }

    class Factory(
        private val extensionRepository: ExtensionRepository,
        private val sourceRepository: SourceRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SourceBrowserViewModel(extensionRepository, sourceRepository) as T
        }
    }
}
